echo hi1
ls
echo hi2 > test1.txt
echo hello > test2.txt
ls & echo hi3
ls & echo hi4 & cat test2.txt
echo cs450 > test3.txt & echo cs450(1) > test4.txt & cat test2.txt
echo 1 >
$
&
echo 1 &
