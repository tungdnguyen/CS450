#include "types.h"
#include "user.h"
#include "syscall.h"

int
main(int argc, char *argv[])
{
  //Case check with write system call
  write(1, "hello\n",5);
  printf(1,"Write count after test write() %d\n",getCallCount(SYS_write));
  printf(1,"Write count after first printf, test printf %d\n",getCallCount(SYS_write));


  //handle invalid system call
  printf(1, "Invalid count %d\n", getCallCount(23));
  printf(1, "Invalid count %d\n", getCallCount(0));

  printf(1,"Write count after invalid count %d\n",getCallCount(SYS_write));


  //handle strcpy
  char src[40];
  memset(src,'\0',sizeof(src));
  strcpy(src,"testing string");
  printf(1,"Write count after strcpy %d\n",getCallCount(SYS_write));

  //test read call
  printf(1,"Read count %d\n",getCallCount(SYS_read));
  char re[50];
  printf(1,"Please input something: \n");
  read(0,re,50);
  printf(1,"Read count %d\n",getCallCount(SYS_read));

  //test other system calls. In this case fork()
  printf(1,"Fork count %d\n",getCallCount(SYS_fork));
  if(fork()==0)
  {
    printf(1,"Write count at first on child process %d\n",getCallCount(SYS_write));
    printf(1, "Child fork count %d\n", getCallCount(SYS_fork));
  }

  else{
    wait();
    printf(1, "Parent fork count %d\n", getCallCount(SYS_fork));
  }

  exit();
}
